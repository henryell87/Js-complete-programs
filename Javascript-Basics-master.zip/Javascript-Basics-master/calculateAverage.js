    // Write a JavaScript program that takes five numbers as
	// input to calculate and print
    // the average of the numbers.
    

function getAllVals() {
    avgNum = 5;
    var num1 = document.getElementById("firstnumber");
    var num2 = document.getElementById(num2);
    var num3 = document.getElementById(num3);
    var num4 = document.getElementById(num4);
    var num5 = document.getElementById(num5);
    num6 = num1+num2+num3+num4+num5*avgNum;
    console.log(num6);
    return num6;


}
